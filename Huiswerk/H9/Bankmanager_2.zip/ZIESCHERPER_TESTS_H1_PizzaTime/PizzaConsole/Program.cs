﻿using System;

namespace PizzaConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            //Gebruik de bestaande Pizza.cs file om daarin je PizzaTime volgens de opgave te maken:

            //Test je code zoals altijd via de main
            //Tevreden over het resultaat? Laat mij nu eens testen: klik bovenaan op "Test" en dan "Run all tests".

            Console.WriteLine("Hello World!");
        }
    }
}
