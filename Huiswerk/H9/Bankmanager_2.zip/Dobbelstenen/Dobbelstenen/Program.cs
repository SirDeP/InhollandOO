﻿namespace Dobbelstenen
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dobbelen wew = new Dobbelen();
            wew.WerpEnTel6();
        }
    }
}
