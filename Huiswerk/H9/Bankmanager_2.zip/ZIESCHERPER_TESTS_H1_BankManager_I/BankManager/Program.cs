﻿using System;

namespace BankManager
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
