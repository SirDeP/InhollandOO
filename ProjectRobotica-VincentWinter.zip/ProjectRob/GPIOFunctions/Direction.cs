﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectRob.GPIOFunctions
{
    internal enum Direction
    {
        North,
        Right,
        South,
        Left
    }
}
