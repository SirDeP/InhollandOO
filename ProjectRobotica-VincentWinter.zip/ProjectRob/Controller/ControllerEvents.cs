﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectRobotica.Controller
{
    internal enum ControllerEvents
    {
        None            = 0x00,
        ButtonAction    = 0x01,
        AxisMoved       = 0x02
    }
}
